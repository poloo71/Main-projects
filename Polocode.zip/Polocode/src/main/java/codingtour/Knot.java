package codingtour;

import java.util.Scanner;

import codingtour.Calculator.Calc;
import codingtour.CodingStation.CodingStation;

public class Knot {

    public static void Intro()
    {
        boolean valid = false;

        System.out.println("\n\n\nWelcome to my coding project!");
        Main.delay(500);  
        System.out.println("I am Knot, and I will be your guide from now on. Where do you want to go?");
        System.out.println();
        Main.delay(500);

        System.out.println("[---- Code station ---------------> Select '1' ");
        System.out.println("[---- Calculus station -----------> Select '2' ");
        System.out.println("[---- Gaming station -------------> Select '3' ");
        System.out.println("[---- To be continued... ---------> Select '4' ");
        System.out.println();

        Scanner sc = new Scanner(System.in);

        while(!valid)
        {
            String choice = sc.nextLine().trim();

            switch(choice)
                {
                    case "1":
                        CodingStation c = new CodingStation();
                        ejection("Code station");
                        c.start();
                        valid = true;
                    break;

                    case "2":
                        Calc calc = new Calc();
                        ejection("Calculus station");
                        calc.start();
                        valid = true;
                    break;

                    case "3":
                        ejection("Gaming station");
                        valid = true;
                    break;

                    case "4":
                        System.out.println("Hello4");
                        ejection("place4");
                        valid = true;
                    break;

                    default:
                        System.out.println("Please, select a valid destination");
                }
        }
       
    }
        
    private static void ejection(String name)
    {
        System.out.print("\n\n");
        System.out.println("[ -- You selected " + name + "!  --]");
        Main.delay(1000);
        System.out.println("[ -- Initializing travel... -- ]\n"); 
        countdown(1000);
    }
    static void countdown(int ms)
    {
        for (int i = 3; i >= 1; i--) 
        {
            Main.delay(ms);
            System.out.println("[ ~~~~  " + i + " ~~~~ ]");
        }
        Main.delay(ms); 
        System.out.print("\n\n");
    }
} 