package codingtour.Calculator;
import java.util.Scanner;

import codingtour.Main;

public class Calc {

    public void CalcStation()
    {
        boolean valid = false;

        System.out.println("[------- You travelled to the Calculus Station! ------- ]");
        Main.delay(1000);           

        System.out.println("[ ------ What do you need? ------ ]\n");
        Main.delay(500);

        System.out.println("[------ Lite Calculator -------------------> Select '1'] ");
        System.out.println("[------ Scientific Calculator -------------> Select '2'] ");
        System.out.println("[------ Base converser --------------------> Select '3'] ");
        System.out.println("[------ Math expression calculator --------> Select '4'] ");
        System.out.println("[------ Statistics mode -------------------> Select '5'] ");
        System.out.println("[------ Units converter -------------------> Select '6'] ");
        System.out.println("[------ Matrix calculator -----------------> Select '7']");
        System.out.println("[------ Cancel ----------------------------> Select '8'] ");
        System.out.println();

        
        Scanner sc = new Scanner(System.in);

        while(!valid)
        {
            int choice = sc.nextInt();

            switch(choice)
                {
                    case 1:
                        LiteCalc lc = new LiteCalc();
                        lc.start();
                        valid = true;
                    break;

                    case 2:
                        
                        valid = true;
                    break;

                    case 3:
                        
                        valid = true;
                    break;

                    case 4:
                        
                        valid = true;
                    break;

                    case 5:
                        
                        valid = true;
                    break;
                    
                    case 6:
                        
                        valid = true;
                    break;

                    case 7:
                        
                        valid = true;
                    break;

                    case 8:
                    break;

                    default:
                        System.out.println("Please, select a valid destination");
                }
        }
    }


    public void start()
    {
        CalcStation();
    }

}
