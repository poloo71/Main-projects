package codingtour.Calculator;

import java.util.Scanner;

import codingtour.Knot;
import codingtour.Main;

public class LiteCalc extends Calc {
    
    public void start()
    {
        System.out.println("\n\n\n[ ----- Welcome to the lite calculator! -----]\n");
        Main.delay(500);
        
        System.out.println("[ ------ Go back to menu: type 'exit' ------ ]");
        System.out.println("[ --------- Input your operation: ---------- ]\n");
        
        
        Scanner sc = new Scanner(System.in);  
        String operation = "";

        while(!operation.equals("exit"))
        {
            int opindex = 0;
            int i = 0;
            int z = 0;
            boolean neg1 = false;
            boolean neg2 = false;

            String sym = "";
            String sign1 = "";
            String sign2 = "";
            
            String op1 = "";
            String op2 = "";

            operation = sc.nextLine().trim(); 

            if(operation.equalsIgnoreCase("exit")) Knot.Intro();

            if(operation.charAt(0) == '-')
            {
                sign1 = "-";
                neg1 = true;
            }

            if(neg1) i = 1;
            for (int k = i ; k < operation.length(); k++) {
                if("+-*/".contains(String.valueOf(operation.charAt(k))))
                {
                    sym = sym + operation.charAt(k);
                    opindex = k;
                    break;
                }
                else op1 = op1 + operation.charAt(k);
            }

            if(operation.charAt(opindex+1) == '-')
            {
                sign2 = "-";
                neg2 = true;
            }

            if(neg2) i = 1; else i = 0;
            for(int k = opindex + 1 + i; k < operation.length(); k++)
            {
                op2 = op2 + operation.charAt(k);
            }

            int n1 = Integer.parseInt(op1);
            int n2 = Integer.parseInt(op2);

            if(neg1) n1 = -n1;
            if(neg2) n2 = -n2;

            if(sym.equals("+"))
            z = n1+n2;

            if(sym.equals("-"))
            z = n1-n2;

            if(sym.equals("*"))
            z = n1*n2;

            if(sym.equals("/"))
            {
                if(n2 != 0) z = n1/n2;
                else System.out.println("Division by zero is impossible.\n\n");
            }
            
            System.out.println("Answer: " + z + "\n");
        }
    }

}

