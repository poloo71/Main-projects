package codingtour.Calculator;
import java.util.Scanner;
import codingtour.Main;

public class Calc {

    public void CalcStation()
    {
        boolean valid = false;
        boolean firstTime = true;
        Scanner sc = new Scanner(System.in);

        while(!valid)
        {    
            if(firstTime)
            {
                System.out.println("\n[------- You travelled to the Calculus Station! ------- ]");
                Main.delay(1000); 
            }
          
            System.out.println("[ ------ What do you need? ------ ]\n");
            Main.delay(500);

            System.out.println("[------ Lite Calculator (2 number operations) --------------------------> Select '1'] ");
            System.out.println("[------ Scientific Calculator (multiple numbers, trigonometrics...)-----> Select '2'] ");
            System.out.println("[------ Base converser -------------------------------------------------> Select '3'] ");
            System.out.println("[------ Math expression calculator -------------------------------------> Select '4'] ");
            System.out.println("[------ Statistics mode ------------------------------------------------> Select '5'] ");
            System.out.println("[------ Units converter ------------------------------------------------> Select '6'] ");
            System.out.println("[------ Matrix calculator ----------------------------------------------> Select '7']");
            System.out.println("[------ Go back to menu ------------------------------------------------> Select '8'] ");
            System.out.println();

            String input = sc.nextLine().trim();
            if(input.isEmpty())
            {
                System.out.println("Please, enter a valid number\n");
                continue;
            }
            int choice = Integer.parseInt(input);

            switch(choice)
                {
                    case 1:
                        LiteCalc lc = new LiteCalc();
                        lc.start();
                    break;

                    case 2:
                        

                    break;

                    case 3:
                        
  
                    break;

                    case 4:
                        
 
                    break;

                    case 5:
                        

                    break;
                    
                    case 6:
                        

                    break;

                    case 7:
                        

                    break;

                    case 8:
                    System.out.println("Going back...");
                    Main.delay(500);
                        return;

                    default:
                        System.out.println("Please, select a valid destination");
                }
        }
    }

    public void start()
    {
        CalcStation();
    }

}

