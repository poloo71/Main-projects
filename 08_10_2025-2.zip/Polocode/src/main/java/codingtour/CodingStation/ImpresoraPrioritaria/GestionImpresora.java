package codingtour.CodingStation.ImpresoraPrioritaria;

public class GestionImpresora 
{
    public static void main(String[] args) {
        
    }

}
