package codingtour.CodingStation.ImpresoraPrioritaria;

public class UsuarioNormal extends Thread
{
    


    @Override
    public void run()
    {

    }
}
