package codingtour.CodingStation.ImpresoraPrioritaria;

public class UsuarioPrioritario extends Thread
{

}
