package codingtour.CodingStation.Restaurante;

public class Restaurante 
{
    public static void main(String[] args) 
    {
        System.out.println();
        Mesa mesa = new Mesa();
        Cocinero c1 = new Cocinero(mesa, "Cocinero1");
        Cocinero c2 = new Cocinero(mesa, "Cocinero2");

        Mesero m1 = new Mesero(mesa, "Mesero1");
        Mesero m2 = new Mesero(mesa, "Mesero2");
        Mesero m3 = new Mesero(mesa, "Mesero3");

        Thread[] hilos = {c1,c2,m1,m2,m3};

        for(Thread hilo : hilos)
        hilo.start();

        for(Thread hilo : hilos)
        {
            try
            {
                hilo.join();
            }
            catch(InterruptedException e){}
        }
  
        System.out.println("\nSimulación del restaurante terminada");
    }
}
