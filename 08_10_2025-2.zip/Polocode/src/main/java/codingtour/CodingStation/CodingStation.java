package codingtour.CodingStation;

import java.util.Scanner;

import codingtour.Main;
import codingtour.CodingStation.Bombonera.Bombonera;

public class CodingStation {

    public void codingMenu()
    {
        boolean valid = false;
        boolean firstTime = true;
        Scanner sc = new Scanner(System.in);

        while(!valid)
        {    
            if(firstTime)
            {
                System.out.println("\n[------- You travelled to the Code Station! ------- ]");
                Main.delay(1000); 
            }
          
            System.out.println("[ ------ Where do you want to go? ------ ]\n");
            Main.delay(500);

            System.out.println("[------ LA BOMBONERA PAPÁ --------------------------> Select '1'] ");
            System.out.println("[------ Go back to menu ----------------------------> Select '2'] ");
            System.out.println();

            String input = sc.nextLine().trim();
            if(input.isEmpty())
            {
                System.out.println("Please, enter a valid number\n");
                continue;
            }
            int choice = Integer.parseInt(input);

            switch(choice)
                {
                    case 1:
                        Bombonera bomb = new Bombonera();
                        bomb.start();
                    break;
                    case 2:
                    System.out.println("Going back...");
                    Main.delay(500);
                        return;

                    default:
                        System.out.println("Please, select a valid destination");

                }
        }
    }

    public void start()
    {
        codingMenu();
    }
    
}
