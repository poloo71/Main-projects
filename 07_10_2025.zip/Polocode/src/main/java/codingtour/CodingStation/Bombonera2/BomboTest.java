package codingtour.CodingStation.Bombonera2;

import java.util.Scanner;

import codingtour.CodingStation.Bombonera2.Entrada.tipoEntrada;

public class BomboTest 
{
    public static void main(String[] args) 
    {
        Estadio bombonera = new Estadio();

        Entrada e1 = new Entrada(tipoEntrada.VIP);
        Entrada e2 = new Entrada(tipoEntrada.ORO);
        Entrada e3 = new Entrada(tipoEntrada.PLATEA);
        Entrada e4 = new Entrada(tipoEntrada.POPULAR);

        Hincha h1 = new Hincha(1, e1, bombonera);
        Hincha h2 = new Hincha(2, e2, bombonera);
        Hincha h3 = new Hincha(3, e3, bombonera);
        Hincha h4 = new Hincha(4, e4, bombonera);
    
        System.out.println();

        h1.start();  
        h2.start();
        h3.start();
        h4.start();

        try
        {
            Thread.sleep(1000);
        }
        catch(InterruptedException e) {}

        Scanner sc = new Scanner(System.in);
        System.out.println("\nABRIMOS LA BOMBONERA????\n");
        System.out.print(">>>>> ");
        String respuesta = sc.nextLine();
  
        if(respuesta.equals("si"))
        {
            System.out.println("\nPUERTAS ABIERTAS\n");
            bombonera.abrirPuertas();
        }
    }
}
