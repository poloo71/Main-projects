package codingtour.CodingStation.Bombonera2;

public class Entrada
{
    tipoEntrada tipo;

    public Entrada(tipoEntrada tipo)
    {
        this.tipo = tipo;
    }

    public enum tipoEntrada
    {
        VIP, ORO, PLATEA, POPULAR
    }

    public tipoEntrada getTipo() {
        return tipo;
    }
}
