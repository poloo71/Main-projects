package codingtour.CodingStation.Bombonera2;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Estadio 
{
    boolean puertasAbiertas = false;
    ReentrantLock lock = new ReentrantLock();
    Condition esperaPuertas = lock.newCondition();

    void abrirPuertas()
    {
        lock.lock();
        try
        {
            puertasAbiertas = true;
            esperaPuertas.signalAll();
        }
        finally
        {
            lock.unlock();
        }
    }

    void esperarPuertas()
    {
        lock.lock();
        try
        {
            while(!puertasAbiertas)
            {
                esperaPuertas.awaitUninterruptibly();
            } 
        }
        finally 
        {
            lock.unlock();
        }
    }
}
