package codingtour.CodingStation.Bombonera2;

public class Hincha extends Thread
{
    int id;
    Estadio estadio;

    public Hincha(int id, Entrada entrada, Estadio estadio)
    {
        this.id = id;
        this.estadio = estadio;
    }

    @Override
    public void run()
    {
        System.out.println("Hincha " + id + " espera a su turno...");
        estadio.esperarPuertas();
         try
        {
            Thread.sleep(id*1000);
        }
        catch(InterruptedException e) {}
        System.out.println("Hincha " + id + " ha entrado al estadio");

    }
}
