package codingtour;

public class Main {
    public static void main(String[] args) {
        Knot.Intro();
    }

    public static void delay(int ms)
    {
        try {
            Thread.sleep(ms);
        } catch (Exception e) {}
    }
}

