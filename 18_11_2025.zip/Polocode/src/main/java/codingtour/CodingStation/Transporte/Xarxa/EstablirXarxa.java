package codingtour.CodingStation.Transporte.Xarxa;

/**
 *
 * @author Marcel Fernandez
 */
public interface EstablirXarxa {
    public Xarxa getExtrem(int extrem);    
}
