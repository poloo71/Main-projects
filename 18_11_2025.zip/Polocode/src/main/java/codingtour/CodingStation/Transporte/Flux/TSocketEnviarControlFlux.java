package codingtour.CodingStation.Transporte.Flux;


import codingtour.CodingStation.Transporte.Xarxa.Comms;
import codingtour.CodingStation.Transporte.Xarxa.Segment;
import codingtour.CodingStation.Transporte.Xarxa.TSocket;
import codingtour.CodingStation.Transporte.Xarxa.Xarxa;



public class TSocketEnviarControlFlux extends TSocket {

    protected int seguentEnviar, seguentASerReconegut, finestraRecepcio;

    public TSocketEnviarControlFlux(Xarxa x) {
        super(x);
        finestraRecepcio = Comms.MIDA_CUA_RECEPCIO;
    }

    @Override
    public void enviar(Object c) {
        try {
            mon.lock();
            //Per enviar segments: xarxa.enviar(seg);

            throw new RuntimeException("Part a completar");
            
            

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            mon.unlock();
        }
    }

    @Override
    public void processarMissatge(Segment segment) {
        mon.lock();
        try {
            throw new RuntimeException("Part a completar");
            
            

            
//            System.out.println("ACK rebut -> " + "finestra recepcio: "
//                    + finestraRecepcio);

        } finally {
            mon.unlock();
        }
    }
}
