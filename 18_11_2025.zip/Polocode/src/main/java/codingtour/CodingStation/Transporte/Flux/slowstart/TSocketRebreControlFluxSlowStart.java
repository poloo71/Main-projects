package codingtour.CodingStation.Transporte.Flux.slowstart;

import codingtour.CodingStation.Transporte.Util.CircularQueue;
import codingtour.CodingStation.Transporte.Xarxa.Comms;
import codingtour.CodingStation.Transporte.Xarxa.Segment;
import codingtour.CodingStation.Transporte.Xarxa.TSocket;
import codingtour.CodingStation.Transporte.Xarxa.Xarxa;

public class TSocketRebreControlFluxSlowStart extends TSocket {

    protected int NextToBeRcv;
    protected CircularQueue cuaRecepcio;

    public TSocketRebreControlFluxSlowStart(Xarxa x) {
        super(x);
        cuaRecepcio = new CircularQueue(Comms.MIDA_CUA_RECEPCIO);
    }

    @Override
    public Object rebre() {
        mon.lock();
        try {
            throw new RuntimeException("Part a completar");
            
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            mon.unlock();
        }
    }

    @Override
    public void processarMissatge(Segment segment) {
        mon.lock();
        try {
            throw new RuntimeException("Part a completar");
            
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            mon.unlock();
        }
    }
}
