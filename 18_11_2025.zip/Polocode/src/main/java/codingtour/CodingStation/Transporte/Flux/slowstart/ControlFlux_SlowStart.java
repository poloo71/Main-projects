/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codingtour.CodingStation.Transporte.Flux.slowstart;

import codingtour.CodingStation.Transporte.Xarxa.Emissor;
import codingtour.CodingStation.Transporte.Xarxa.EstablirXarxa;
import codingtour.CodingStation.Transporte.Xarxa.EstablirXarxaDatagrama;
import codingtour.CodingStation.Transporte.Xarxa.Receptor;


public class ControlFlux_SlowStart {

    public static void main(String[] args) {
        EstablirXarxa xarxa = new EstablirXarxaDatagrama();
        TSocketEnviarControlFluxSlowStart socketEnviar = 
                             new TSocketEnviarControlFluxSlowStart(xarxa.getExtrem(0));
        TSocketRebreControlFluxSlowStart socketRebre = 
                             new TSocketRebreControlFluxSlowStart(xarxa.getExtrem(1));    
        new Thread(new Receptor(socketRebre)).start();
        new Thread(new Emissor(socketEnviar)).start();
    }
}









