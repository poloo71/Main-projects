/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package codingtour.CodingStation.Transporte.Estats;

import codingtour.CodingStation.Transporte.Xarxa.EstablirXarxa;
import codingtour.CodingStation.Transporte.Xarxa.EstablirXarxaDatagrama;

public class CanviEstats {
    public static void main(String[] args) {
        try {
        EstablirXarxa xarxa = new EstablirXarxaDatagrama();
        TSocketCanviEstats socketA = 
                             new TSocketCanviEstats2(xarxa.getExtrem(0));
        TSocketCanviEstats socketB = 
                             new TSocketCanviEstats2(xarxa.getExtrem(1));              
            new Thread(new ExtremB(socketB)).start();
            Thread.sleep(100);
            new Thread(new ExtremA(socketA)).start();
            
        } catch (Exception ex) {
            System.out.println(ex);
        } 
    }
    
}
