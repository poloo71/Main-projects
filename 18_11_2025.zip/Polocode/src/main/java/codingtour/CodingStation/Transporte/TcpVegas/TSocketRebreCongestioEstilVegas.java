/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codingtour.CodingStation.Transporte.TcpVegas;

import codingtour.CodingStation.Transporte.Util.CircularQueue;
import codingtour.CodingStation.Transporte.Xarxa.Comms;
import codingtour.CodingStation.Transporte.Xarxa.Segment;
import codingtour.CodingStation.Transporte.Xarxa.SegmentDelayed;
import codingtour.CodingStation.Transporte.Xarxa.TSocket;
import codingtour.CodingStation.Transporte.Xarxa.Xarxa;

public class TSocketRebreCongestioEstilVegas extends TSocket{
    protected CircularQueue cuaRecepcio;

    public TSocketRebreCongestioEstilVegas(Xarxa x) {
        super(x);
        cuaRecepcio = new CircularQueue<>(Comms.MIDA_CUA_RECEPCIO);
    }

    public Object rebre() {
        mon.lock();
        try {
            throw new RuntimeException("Part a completar");

            
            
            
            
        } finally {                   
            mon.unlock();
        }

    }


    public void processarMissatge(Segment missatge) {
        mon.lock();
        try{
            throw new RuntimeException("Part a completar");


            
            
            
            

        } catch (Exception e) { System.out.println(e);
        } finally {
            mon.unlock();
        }
    }
}