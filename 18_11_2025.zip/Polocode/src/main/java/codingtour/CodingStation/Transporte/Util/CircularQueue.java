package codingtour.CodingStation.Transporte.Util;
import java.util.Iterator;

public class CircularQueue<E> implements Queue<E> {

    private final E[] queue;
    private final int N;
    private int numElem, head, tail;

    public CircularQueue(int N) {
        this.N = N;
        queue = (E[]) (new Object[N]);
    }

    @Override
    public int size() {
        return numElem;
    }

    @Override
    public int free() {
        return N - numElem;
    }

    @Override
    public boolean empty() {
        return numElem == 0;
    }

    @Override
    public boolean full() {
        return numElem == N;
    }

    @Override
    public E peekFirst() {
        if (numElem == 0) {
            throw new IllegalStateException("Empty queue.");
        }
        return queue[head];
    }

    @Override
    public E get() {
        if (numElem == 0) {
            throw new IllegalStateException("Empty queue.");
        }
        E e = queue[head];
        head = (head + 1) % N;
        numElem = numElem - 1;
        return e;
    }

    @Override
    public void put(E e) {
        if (numElem == N) {
            throw new IllegalStateException("Full queue.");
        }
        queue[tail] = e;
        tail = (tail + 1) % N;
        numElem = numElem + 1;
    }

    @Override
    public String toString() {
        if (numElem == 0) {
            return "[]";
        }
        String str = "[";
        for (int i = 0; i < numElem - 1; i++) {
            str = str + queue[(head + i) % N] + ", ";
        }
        str = str + queue[(head + numElem - 1) % N] + "]";
        return str;
    }

    @Override
    public Iterator<E> iterator() {
        return new MyIterator();
    }

    class MyIterator implements Iterator {

        int index = 0;

        @Override
        public boolean hasNext() {
            return index < numElem;
        }

        @Override
        public E next() {
            if (index == numElem) {
                throw new IllegalStateException("There is no next element.");
            }
            E tmp = queue[(head + index) % N];
            index++;
            return tmp;
        }

        @Override
        public void remove() {
            if (index < 1) {
                throw new IllegalStateException("Cannot remove element.");
            }
            index--;
            for (int i = index; i < numElem; i++) {
                queue[(head + i) % N] = queue[(head + 1 + i) % N];
            }
            tail = (tail + N - 1) % N;
            numElem--;
        }

    }
}
