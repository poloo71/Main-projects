package codingtour.CodingStation.Monitores.ImpresoraPrioritaria;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Impresora
{
    LinkedList<String> colaimpresion = new LinkedList<>();
    ReentrantLock lock = new ReentrantLock();
    Condition impresoraEnUso = lock.newCondition();

    void agregarTrabajoNormal(String trabajo)
    {
        colaimpresion.add(trabajo);
    }

    void agregarTrabajoPrioritario(String trabajo)
    {
        for (int i = 0; i < colaimpresion.size(); i++) 
        {
            if(colaimpresion.get(i).isEmpty())
            {
                colaimpresion.add(i, trabajo);
                break;
            }
        }  
    }

    void iniciar()
    {
        lock.lock();
        try
        {
            String impresion;
            while(colaimpresion.isEmpty())
            impresoraEnUso.awaitUninterruptibly();

            for (int i = 0; i < colaimpresion.size(); i++) 
            {
                if(!colaimpresion.get(i).isEmpty())
                impresion = colaimpresion.remove(i);
                System.out.println("Empezando a imprimir impresion " + colaimpresion.get(i));
            }
        }
        finally
        {
            lock.unlock();
        }
    }



}
