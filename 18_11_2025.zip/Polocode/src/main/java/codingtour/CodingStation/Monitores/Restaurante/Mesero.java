package codingtour.CodingStation.Monitores.Restaurante;

public class Mesero extends Thread
{
    private Mesa mesa;
    private String nombre;

    public Mesero (Mesa mesa, String nombre)
    {
        super(nombre);
        this.mesa = mesa;  
        this.nombre = nombre;
    }
    public void run()
    {
        for (int i = 0; i < 3; i++) 
        {
            String plato = mesa.tomarPlato();
            System.out.println(nombre + " sirvió " + plato);
            try
            {
                Thread.sleep(1500);
            } 
            catch(InterruptedException e) 
            {
                e.printStackTrace();
            }
        }
    }
}
