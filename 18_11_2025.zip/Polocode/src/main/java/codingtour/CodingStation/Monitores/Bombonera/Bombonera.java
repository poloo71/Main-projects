package codingtour.CodingStation.Monitores.Bombonera;

import java.util.Scanner;

public class Bombonera {

    public static void main(String[] args) {
        new Bombonera().start();
    }

    public void start() 
    {
        Estadio bombonera = new Estadio();

        try 
        {
            Thread.sleep(1000);
        }
        catch (InterruptedException e) {}

        Scanner sc = new Scanner(System.in);
        System.out.println("\n\nBIENVENIDO A LA BOMBONERA PAPÁ");
        delay(1000);
        System.out.println("\nABRIMOS LA BOMBONERA????\n");
        System.out.print(">>>>> ");

        String respuesta = sc.nextLine().trim().toLowerCase();
        while (!respuesta.equals("si")) 
        {
            System.out.println("SI O NO?????");
            respuesta = sc.nextLine().trim().toLowerCase();
        }

        if (respuesta.equals("si")) 
        {
            delay(1000);
            System.out.println("\nPUERTAS ABIERTAS\n");

            Hincha h1 = new Hincha(1, Entrada.tipoEntrada.VIP, bombonera);
            Hincha h2 = new Hincha(2, Entrada.tipoEntrada.ORO, bombonera);
            Hincha h3 = new Hincha(3, Entrada.tipoEntrada.PLATEA, bombonera);
            Hincha h4 = new Hincha(4, Entrada.tipoEntrada.POPULAR, bombonera);

            System.out.println();

            h1.start();
            h2.start();
            h3.start();
            h4.start();

            bombonera.abrirPuertas();

            try 
            {
                h1.join();
                h2.join();
                h3.join();
                h4.join();
            }
            catch (InterruptedException e) 
            {
                Thread.currentThread().interrupt();
            }
        }
    }

    private static void delay(int millis) 
    {
        try 
        {
            Thread.sleep(millis);
        } 
        catch (InterruptedException e){}
    }
}
