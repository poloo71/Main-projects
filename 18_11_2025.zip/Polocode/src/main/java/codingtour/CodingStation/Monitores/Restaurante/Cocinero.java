package codingtour.CodingStation.Monitores.Restaurante;

public class Cocinero extends Thread 
{
    Mesa mesa;
    String nombre;

    public Cocinero(Mesa mesa, String nombre)
    {
        super(nombre);
        this.mesa = mesa;
        this.nombre = nombre;
    }

    @Override
    public void run()
    {
        for (int i = 0; i < 5; i++) 
        {
            String plato = "Plato -> " + nombre + " <- " + i;
            mesa.ponerPlato(plato);
            try
            {
                Thread.sleep(1000);
            } 
            catch(InterruptedException e) 
            {
                e.printStackTrace();
            }     
        }
    }
}
