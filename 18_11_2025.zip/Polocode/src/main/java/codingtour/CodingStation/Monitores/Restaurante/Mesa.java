package codingtour.CodingStation.Monitores.Restaurante;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;


public class Mesa 
{
    private LinkedList<String> platos = new LinkedList<>();
    private final int CAPACIDAD_MAXIMA = 3;
    private ReentrantLock lock = new ReentrantLock();
    Condition mesaNoLLena = lock.newCondition();
    Condition mesaNoVacia = lock.newCondition();

    public void ponerPlato(String plato)
    {
        lock.lock();
        try
        {
            while(platos.size() == CAPACIDAD_MAXIMA)
            {
                mesaNoLLena.awaitUninterruptibly();
            }
            platos.add(plato);
            System.out.println("Cocinero puso " + plato);
            mesaNoVacia.signalAll();
        }
        finally
        {
            lock.unlock();
        }
    }

    public String tomarPlato()
    {
        lock.lock();
        try
        {
            while(platos.isEmpty())
            mesaNoVacia.awaitUninterruptibly();

            String plato = platos.remove(0);
            System.out.println("El mesero tomó " + plato);
            mesaNoLLena.signalAll();
            return plato;
        }
        finally
        {
            lock.unlock();
        }
    }
}
