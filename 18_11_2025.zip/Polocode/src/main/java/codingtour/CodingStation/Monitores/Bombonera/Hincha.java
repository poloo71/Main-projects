package codingtour.CodingStation.Monitores.Bombonera;

public class Hincha extends Thread
{
    int id;
    Estadio estadio;
    Entrada.tipoEntrada tipo;


    public Hincha(int id, Entrada.tipoEntrada tipo, Estadio estadio)
    {
        this.id = id;
        this.estadio = estadio;
        this.tipo = tipo;
    }

    @Override
    public void run()
    {
        if(!estadio.comprarEntrada(tipo))
        {
            System.out.println("Hincha " + id + " no pudo comprar su entrada de tipo " + tipo);
            return;
        }
        try
        {
            Thread.sleep(500);
        }
        catch(InterruptedException e) {}
        System.out.println("Hincha " + id + " espera a su turno...");
        estadio.esperarPuertas();
         try
        {
            Thread.sleep(id*1000);
        }
        catch(InterruptedException e) {}
        System.out.println("Hincha " + id + " ha entrado al estadio");
    }
}
