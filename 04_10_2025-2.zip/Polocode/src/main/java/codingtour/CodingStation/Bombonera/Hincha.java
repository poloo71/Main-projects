package codingtour.CodingStation.Bombonera;

public class Hincha extends Thread {
    private final int id;
    private final String tipoEntrada;
    private final Entradas entradas;
    private final Bombonera bombonera;

    public Hincha(int id, String tipoEntrada, Entradas entradas, Bombonera bombonera) {
        this.id = id;
        this.tipoEntrada = tipoEntrada;
        this.entradas = entradas;
        this.bombonera = bombonera;
    }

   @Override
public void run() {
    System.out.println("Hincha " + id + " (" + tipoEntrada + ") está esperando...");

    try {
        bombonera.esperarEstadio(); // espera a que abran
    } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        return;
    }

    // 1. Reserva la entrada (rápido y atómico)
    boolean entro = bombonera.intentarEntrar(entradas, tipoEntrada);

    // 2. Ahora, con el lock ya liberado, hacemos el delay
    try {
        Thread.sleep(1000); // espera 1 segundo antes de mostrar el resultado
    } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        return;
    }

    // 3. Mostramos el resultado
    if (entro) {
        System.out.println("✅ Hincha " + id + " entró con entrada " + tipoEntrada);
    } else {
        System.out.println("❌ Hincha " + id + " NO entró: sin entradas de " + tipoEntrada);
    }
}}