package codingtour.CodingStation.Bombonera;

import java.util.Scanner;

public class BomboneraMain {
    public static void main(String[] args) throws InterruptedException {
        Entradas entradas = new Entradas();
        Bombonera estadio = new Bombonera();

        System.out.println("/// BIENVENIDO A LA BOMBONERA, LA CASA DEL FUTBOL ///");
        System.out.println("¿Quieres abrir el estadio? (escribe 'si' para abrir)");

        // Crear e iniciar los hinchas (ellos esperarán a que se abra)
        Hincha[] hinchas = {
            new Hincha(1, "VIP", entradas, estadio),
            new Hincha(2, "VIP", entradas, estadio),
            new Hincha(3, "VIP", entradas, estadio), // ← este no entrará
            new Hincha(4, "ORO", entradas, estadio),
            new Hincha(5, "PLATEA", entradas, estadio),
            new Hincha(6, "POPULAR", entradas, estadio)
        };

        for (Hincha h : hinchas) {
            h.start();
        }

        // Leer respuesta del usuario
        Scanner sc = new Scanner(System.in);
        String respuesta = sc.nextLine();

        // ✅ Usa .equals(), no ==
        if ("si".equals(respuesta)) {
            estadio.abrirEstadio(); // ← esto notifica a los hinchas
        } else {
            System.out.println("El estadio permanece cerrado. Los hinchas se van.");
            return;
        }

        // Esperar a que todos los hinchas terminen
        for (Hincha h : hinchas) {
            h.join();
        }

        System.out.println("\n🎉 Simulación finalizada.");
    }
}