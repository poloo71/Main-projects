package codingtour.CodingStation.Bombonera;

import java.util.HashMap;
import java.util.Map;

public class Entradas {

    private Map<String, Integer> cupos;
    boolean EntradasDisp = false;

    public Entradas()
    {
        cupos = new HashMap<>();
        cupos.put("VIP", 2);
        cupos.put("ORO", 10);
        cupos.put("PLATEA", 20);
        cupos.put("POPULAR", 40);
    }

   boolean reservarEntrada(String tipo) {
        Integer actuales = cupos.get(tipo);
        if (actuales != null && actuales > 0) {
            cupos.put(tipo, actuales - 1);
            return true;
        }
        return false;
    }
}
