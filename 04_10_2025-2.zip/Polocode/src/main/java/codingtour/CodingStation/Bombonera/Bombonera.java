package codingtour.CodingStation.Bombonera;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;



public class Bombonera 
{
    ReentrantLock lock = new ReentrantLock();
    Condition condicionAbrir = lock.newCondition();
    boolean estadioabierto = false;

    public boolean estadioabierto()
    {
        return estadioabierto;
    }

    public void esperarEstadio() throws InterruptedException
    {
        lock.lock();
        try
        {
            while(!estadioabierto)
            condicionAbrir.await();
        }
        finally
        {
            lock.unlock();
        }
    }

    public void abrirEstadio()
    {
        lock.lock();
        try
        {
            estadioabierto = true;
            condicionAbrir.signalAll();
            System.out.println("Abriendo estadio...\n\n");

        }
        finally
        {
            lock.unlock();
        }
    }
public boolean intentarEntrar(Entradas entradas, String tipo) {
        lock.lock();
        try {
            return entradas.reservarEntrada(tipo);
        } finally {
            lock.unlock();
        }
    }

}
