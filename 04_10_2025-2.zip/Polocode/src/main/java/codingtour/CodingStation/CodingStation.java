package codingtour.CodingStation;

public class CodingStation {

    void Menu ()
    {
        System.out.println("hello");
    }

    public void start()
    {
        
    }
    
}
