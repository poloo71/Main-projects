package codingtour.Calculator;

import java.util.Scanner;
import codingtour.Main;

public class LiteCalc extends Calc 
{

    public void start() 
    {
        System.out.println("\n\n\n[ ----- Welcome to the lite calculator! -----]\n");
        Main.delay(500);

        System.out.println("[ ------ Go back to menu: type 'exit' ------ ]");
        System.out.println("[ --------- Input your operation: ---------- ]\n");     //Input request.
        

        Scanner sc = new Scanner(System.in);

        while (true)            // We make a loop until we want to go back to menu 
        {
            System.out.print(">>>>> ");

            String operation = "";

            int opindex = 0;        // Utility variable to travel through the string input.
            int i = 0;
            double z = 0;

            boolean neg1 = false;       // First number negative switch
            boolean neg2 = false;       // Second number negative switch

            String sym = "";        // Operation symbol (+-*/)

            String op1 = "";        // First operator
            String op2 = "";        //Second operator

            operation = sc.nextLine().trim();
            operation = operation.replaceAll("\\s+", "");   //We clean the spaces from the input

            if (operation.equalsIgnoreCase("exit"))         //Go back to menu
                return;

            if (operation.trim().isEmpty()) 
            {
                System.out.println("Empty operation, try again");
                continue;
            }

            if (operation.length() < 3)         //Validates if the input can take a full operation (1+1)
            {
                System.out.println("Invalid operation\n");
                continue;
            }


            if (operation.charAt(0) == '-' || operation.charAt(0) == '+')       //Multiple symbol conditionals (Does not allow more than 2 consecutive symbols)
            {
                if (!(operation.charAt(1) == '*' || operation.charAt(1) == '/')) 
                {
                    if (operation.charAt(0) == '+' && operation.charAt(1) == '-') 
                    {
                        neg1 = true;
                        i = 2;
                    }
                    else if (operation.charAt(0) == '+' && operation.charAt(1) == '+')
                        neg1 = false;

                    else if (operation.charAt(0) == '-' && operation.charAt(1) == '-')
                        neg1 = false;

                    else if (operation.charAt(0) == '-' && operation.charAt(1) == '+') 
                    {
                        neg1 = true;
                        i = 2;
                    } 
                    else if (operation.charAt(0) == '-') 
                    {
                        i = 1;
                        neg1 = true;
                    } 
                    else if (operation.charAt(0) == '+') 
                    {
                        i = 1;
                        neg1 = false;
                    }
                } 
                else 
                {
                    System.out.println("Invalid operation\n");      //Case *5+1
                    continue;
                }
            }

            for (int k = i; k < operation.length(); k++) 
            {
                if ("+-*/".contains(String.valueOf(operation.charAt(k)))) 
                {
                    sym = sym + operation.charAt(k);
                    opindex = k;
                    break;
                } 
                else op1 = op1 + operation.charAt(k); // First number obtained
            }

            if (op1.isEmpty()) 
            {
                System.out.println("Invalid operation\n");
                continue;
            }

            if (operation.charAt(opindex + 1) == '-' || operation.charAt(opindex + 1) == '+') //Second number symbol conditionals
            {
                if (opindex + 2 < operation.length() && (operation.charAt(opindex + 2) == '-' || operation.charAt(opindex + 2) == '+')) 
                {
                    if (operation.charAt(opindex + 1) == '-' && operation.charAt(opindex + 2) == '-') 
                    {
                        neg2 = false;
                        i = 2;
                    } 
                    else if (operation.charAt(opindex + 1) == '-' && operation.charAt(opindex + 2) == '+') 
                    {
                        neg2 = true;
                        i = 2;
                    } 
                    else if (operation.charAt(opindex + 1) == '+' && operation.charAt(opindex + 2) == '+') 
                    {
                        neg2 = false;
                        i = 2;
                    } 
                    else if (operation.charAt(opindex + 1) == '+' && operation.charAt(opindex + 2) == '-') 
                    {
                        neg2 = true;
                        i = 2;
                    } 
                    else 
                    {
                        System.out.println("Invalid operation\n");
                        continue;
                    }
                }

                else if(operation.charAt(opindex + 1) == '-')
                {
                    i = 1;
                    neg2 = true;
                }
                else if(operation.charAt(opindex + 1) == '+')
                {
                    i = 1;
                    neg2 = false;
                }

            }

            else 
            {
                i = 0;
                neg2 = false;
            }


            for (int k = opindex + 1 + i; k < operation.length(); k++)  // We navigate from the first non-symbol digit to the last one
                op2 = op2 + operation.charAt(k);        //Second number obtained

            if (op2.isEmpty()) 
            {
                System.out.println("Invalid operation\n");
                continue;
            }
            try
            {
                Double n1 = Double.parseDouble(op1);
                Double n2 = Double.parseDouble(op2);

                if (neg1) n1 = -n1;

                if (neg2) n2 = -n2;

                if (sym.equals("+")) 
                {
                    z = n1 + n2;
                    System.out.println("Answer: " + z + "\n");
                }

                if (sym.equals("-")) 
                {
                    z = n1 - n2;
                    System.out.println("Answer: " + z + "\n");
                }

                if (sym.equals("*")) 
                {
                    z = n1 * n2;
                    System.out.println("Answer: " + z + "\n");
                }

                if (sym.equals("/")) 
                {
                    if (n2 != 0)
                    {
                        z = n1 / n2;
                        z = Math.round(z * 100.0) / 100.0; 
                        System.out.println("Answer: " + z + "\n");
                    }
                    else System.out.println("Division by zero is impossible.\n\n");
                }
            }
            catch(NumberFormatException e)
            {
                System.out.println("Invalid operation\n");
                continue;
            }
        }
    }
}

