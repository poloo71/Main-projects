package codingtour.CodingStation.Bombonera;

import java.util.HashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import codingtour.CodingStation.Bombonera.Entrada.tipoEntrada;

public class Estadio 
{
    boolean puertasAbiertas = false;
    ReentrantLock lock = new ReentrantLock();
    Condition esperaPuertas = lock.newCondition();

    HashMap<Entrada.tipoEntrada, Integer> stock;

    public Estadio()
    {
        stock = new HashMap<>();
        for(Entrada.tipoEntrada tipo : Entrada.tipoEntrada.values())
        {
            stock.put(tipo, tipo.getCapacidad());
        }
    }

    public boolean comprarEntrada(tipoEntrada tipo)
    {
        lock.lock();
        try
        {
            Integer capacidad = stock.get(tipo);
            if(capacidad <= 0)
            {
                try
                {
                    Thread.sleep(500);
                }
                catch(InterruptedException e) {}
                System.out.println("No quedan más entradas de tipo " + tipo);
                return false;
            } 
            else
            {
                try
                {
                    Thread.sleep(500);
                }
                catch(InterruptedException e) {}
                stock.put(tipo, capacidad-1 );
                System.out.println("Entrada de tipo " + tipo + " comprada, quedan " + (capacidad-1) + " disponibles" );
                return true;
            }
        }
        finally
        {
            lock.unlock();
        }

    }

    void abrirPuertas()
    {
        lock.lock();
        try
        {
            puertasAbiertas = true;
            esperaPuertas.signalAll();
        }
        finally
        {
            lock.unlock();
        }
    }

    void esperarPuertas()
    {
        lock.lock();
        try
        {
            while(!puertasAbiertas)
            {
                esperaPuertas.awaitUninterruptibly();
            } 
        }
        finally 
        {
            lock.unlock();
        }
    }
}
