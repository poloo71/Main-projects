package codingtour.CodingStation.Bombonera;

public class Entrada
{
    tipoEntrada tipo;

    public Entrada(tipoEntrada tipo)
    {
        this.tipo = tipo;
    }

    public tipoEntrada getTipo() 
    {
        return tipo;
    }
    
    public enum tipoEntrada
    {
        VIP(1), ORO(5), PLATEA(7), POPULAR(10);
        int capacidad;

        tipoEntrada(int capacidad)
        {
            this.capacidad = capacidad;
        }

        public int getCapacidad() 
        {
            return capacidad;
        }

    }


    
}
