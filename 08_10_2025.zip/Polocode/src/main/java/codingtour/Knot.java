package codingtour;

import java.util.Scanner;

import codingtour.Calculator.Calc;
import codingtour.CodingStation.CodingStation;

public class Knot {

    public static void Intro()
    {
        boolean end = false;
        boolean firstTime = true;
        Scanner sc = new Scanner(System.in);

        while(!end)
        {
            if(firstTime)
            {
                System.out.println("\n\n\nWelcome to my coding project!");
                Main.delay(500);
                System.out.println("I am Knot, and I will be your guide from now on.");
                System.out.println();
                Main.delay(500);
                firstTime = false;
            }
            Main.delay(500);
            System.out.println("Where do you want to go?\n");
            Main.delay(500);
            System.out.println("[------- Code station (Multithreading examples, all kind of java manipulations...) ----------------> Select '1' ");
            System.out.println("[------- Calculus station (Math operations, base conversion, statistics...) -----------------------> Select '2' ");
            System.out.println("[------- Gaming station (Java-related games, all kind of fun programs) ----------------------------> Select '3' ");
            System.out.println("[------- Exit the world ---------------------------------------------------------------------------> Select '4' ");
            System.out.println();

            System.out.print(">>>> ");  
            String choice = sc.nextLine().trim();

            switch(choice)
                {
                    case "1":
                        CodingStation c = new CodingStation();
                        ejection("Code station");
                        c.start();
                    break;

                    case "2":
                        Calc calc = new Calc();
                        ejection("Calculus station");
                        calc.start();
                    break;

                    case "3":
                        ejection("Gaming station");
                    break;

                    case "4":
                        System.out.println("Goodbye!\n\n\n");
                        Main.delay(300);
                        end = true;
                    break;

                    default:
                        System.out.println("Please, select a valid destination\n");
                }
        }
       
    }
        
    private static void ejection(String name)
    {
        System.out.print("\n\n");
        System.out.println("[ -- You selected " + name + "!  --]");
        Main.delay(700);
        System.out.println("[ -- Initializing travel... -- ]\n"); 
        countdown(700);
    }
    static void countdown(int ms)
    {
        for (int i = 3; i >= 1; i--) 
        {
            Main.delay(ms);
            System.out.println("[ ~~~~  " + i + " ~~~~ ]");
        }
        Main.delay(ms); 
        System.out.print("\n\n");
    }
} 